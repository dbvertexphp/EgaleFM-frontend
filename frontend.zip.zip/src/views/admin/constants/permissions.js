// // src/constants/permissions.js
// export const ALLOWED_PERMISSIONS = [
//   "users",
//   "service_provider",
//   "unverified_service_provider",
//   "both",
//   "all_service_provider",
//   "requests",
//   "work_category",
//   "platform_fee",
//   "biding",
//   "direct-hiring",
//   "emergency-hiring",
//   "direct_payment_request",
//   "dispute",
//   "contact-us",
//   "email-us",
//   "add-aboutus",
// 	"add-terms-conditions",
// 	"add-privacypolicy",
// 	"chat_monitor",	
// 	"promotion"
// ];
